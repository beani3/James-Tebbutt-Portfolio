﻿public enum UFT_BTNodeStates
{
    SUCCESS,
    FAILURE,
}

